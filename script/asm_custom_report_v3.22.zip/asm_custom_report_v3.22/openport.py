import pandas as pd
import requests
import json
from docx import Document
import re
import socket

from const_asm_apiendpoint import *
import report_util as util

# ------------------------------------------------------------
def create_report(document:Document,table_num:int,projectID:int,collectionName:str)->Document:

    print("# openport_report")

    docName=("ASM_CustomReport_"+projectID+"-"+collectionName+"_Output.docx")

    # get inferredCVE entities from collection
    # Index(['cve', 'cwe', 'cvss_v2', 'cvss_v3', 'exploits', 'references',
    #        'short_name', 'description', 'cvss_v2_score', 'cvss_v3_score',
    #        'mandiant_intel_details', 'entityname', 'cpe', 'technology'],
    print("Populating IPAddress Entities...")
    search_query = "hidden:false type:NetworkService"
    entities_netserv_df = util.search_data(project_id=projectID,collectionName=collectionName,type="entity",query=search_query)

    if len(entities_netserv_df) == 0:
        print("No NetworkService Entities.")
        return document

    entities_netserv_df.to_csv("test.csv")

    # 3. 処理用の列(df.url)を作成して、entity_nameのurl要素を抽出して格納
    re_ipv4 = '^(([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])'
    entities_netserv_df[["ipv4addr"]] = entities_netserv_df["name"].str.extract(r"^([^:]*).")
    entities_netserv_df[["port"]]     = entities_netserv_df["name"].str.extract(r"^[^:]*:(.*)")
    entities_netserv_df[["portnum"]]  = entities_netserv_df["name"].str.extract(r"^[^:]*:(\d+)")
    entities_netserv_df["portnum"] = pd.to_numeric(entities_netserv_df["portnum"])
    ipv4_addrs = entities_netserv_df["ipv4addr"].unique()

    t = table_num  # table_number
    count = 1 # rows_count

    for ipaddr in ipv4_addrs:
        port_df = entities_netserv_df[ entities_netserv_df["ipv4addr"] == ipaddr].sort_values("portnum")
        openports_str = ", ".join( port_df[ port_df["ipv4addr"] == ipaddr]["port"].to_list() )

        detail = util.get_entity_detail(project_id=projectID,entity_uid=port_df.iloc[0]["id"])
        ancestors =  detail["ancestors"][0]["name"]
        document.tables[t].add_row()
        util.cell_writeout(cell=document.tables[t].rows[count].cells[0], text= ipaddr )
        util.cell_writeout(cell=document.tables[t].rows[count].cells[1], text= ancestors)
        util.cell_writeout(cell=document.tables[t].rows[count].cells[2], text= openports_str )
        count = count + 1

    document.save(docName)
    print("Report generated: "+docName+"\n")
    return document


# ------------------------------------------------------------
if __name__ == "__main__":
    print("Please run API_ASM2Worn.py")



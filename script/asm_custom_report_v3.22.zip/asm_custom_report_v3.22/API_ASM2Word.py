import pandas as pd
import requests
import json
from docx import Document

from dotenv import load_dotenv
import os
load_dotenv()

from const_asm_apiendpoint import *
import base_report
import inferred_cve
import openport
import domain

# ------------------------------------------------------------
# Report extention by kiri
# v3.21 2023/12/28: bugfix (issue description:nan)
# v3.20 2023/12/04: modify openport repot
# v3.10 2023/11/20: refactoring.
# v3.00 2023/11/12: merged with v2 report (base_report).
# v2.30 2023/11/05: +openport report.
# v2.20 2023/10/22: +domain report.
# v2.10 2023/09/22: +inferredCVE report.


accessKey = os.getenv('ASM_ACCESS_KEY')
accessSecret = os.getenv('ASM_ACCESS_SECRET')
headers = {"INTRIGUE_ACCESS_KEY":accessKey, "INTRIGUE_SECRET_KEY":accessSecret}

#list projects and choose project
response = requests.get((baseUrl+projectsEndPoint), headers=headers)
print("Available Projects To Select From:")

for project in response.json()['result']:
    print("\t Project ID: "+str(project['id'])+" Project Name: "+project['name'])
#get projectID
projectID=input("Please enter the projectID of the project where your data resides: ")
#add to headers
headers['PROJECT_ID']=str(projectID)

#list collections and choose collection
response=requests.get((baseUrl+collectionsEndPoint),headers=headers)
collections_df = pd.DataFrame.from_records(response.json()['result'])
print("Available Collections To Select From:")
for project in response.json()['result']:
    print("\t Collection Name: "+project['name'])

#get collection name & UUID
collectionName=input("Please enter the collectionName of the Collection you'd like to report on: ")
collectionUUID=collections_df.loc[collections_df['name']==collectionName,'uuid'].iloc[0]

#create repot.
doc = Document('ASM_template_V3.docx')
doc = base_report.create_report (document=doc,table_num=7,projectID=projectID,collectionName=collectionName)
doc = inferred_cve.create_report(document=doc,table_num=4,projectID=projectID,collectionName=collectionName)
doc = openport.create_report    (document=doc,table_num=5,projectID=projectID,collectionName=collectionName)
doc = domain.create_report      (document=doc,table_num=6,projectID=projectID,collectionName=collectionName)
doc.save("ASM_CustomReport_"+projectID+"-"+collectionName+"_Output.docx")

exit()

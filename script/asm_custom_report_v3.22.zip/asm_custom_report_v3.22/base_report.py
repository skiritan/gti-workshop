import pandas as pd
import requests
import json
from docx import Document
from docx.shared import Pt
from docx.text.paragraph import Paragraph

import numpy as np
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.xmlchemy import OxmlElement
from docx.oxml.ns import qn

from dotenv import load_dotenv
import os
load_dotenv()

from const_asm_apiendpoint import *
import report_util as util

accessKey = os.getenv('ASM_ACCESS_KEY')
accessSecret = os.getenv('ASM_ACCESS_SECRET')
headers = {"INTRIGUE_ACCESS_KEY":accessKey, "INTRIGUE_SECRET_KEY":accessSecret}

#helper dicts:
sev_dict = {'1':"Critical", '2':"High", '3':"Medium", '4':"Low", '5':"Informational"}
sevcolor_dict = {'1':"C00000", '2':"DE6F73", '3':"FFFF00", '4':"9FB8E2", '5':"D9D9D9"}

#helper functions
def _set_cell_background(cell, fill, color=None, val=None):
    """
    @fill: Specifies the color to be used for the background
    @color: Specifies the color to be used for any foreground
    pattern specified with the val attribute
    @val: Specifies the pattern to be used to lay the pattern
    color over the background color.
    """
    cell_properties = cell._element.tcPr
    try:
        cell_shading = cell_properties.xpath('w:shd')[0]  # in case there's already shading
    except IndexError:
        cell_shading = OxmlElement('w:shd') # add new w:shd element to it
    if fill:
        cell_shading.set(qn('w:fill'), fill)  # set fill property, respecting namespace
    if color:
        pass # TODO
    if val:
        pass # TODO
    cell_properties.append(cell_shading)  # finally extend cell props with shading element

def to_str(var):
    return str(list(np.reshape(np.asarray(var), (1, np.size(var)))[0]))[1:-1]

def _par_writeout(par:Paragraph,text:str,fontname:str="Calibri",fontsize:int=10):
    par.text = text
    par.runs[0].font.name = fontname
    par.runs[0].font.size = Pt(fontsize)

# ------------------------------------------------------------
def create_report(document:Document,table_num:int,projectID:int,collectionName:str)->Document:
    
    print("# base_report")
    headers['PROJECT_ID']=str(projectID)
    docName=("ASM_CustomReport_"+projectID+"-"+collectionName+"_Output.docx")

    #Populate Issues Library
    #Index(['added', 'name', 'pretty_name', 'severity', 'category', 'status',
    #       'description', 'remediation', 'references', 'affected_software', 'task',
    #        'identifiers', 'authors', 'uses_dns_exfil', 'dns_exfil_options',
    #       'affected_ports', 'affected_fingerprint_tags', 'check', 'proof',
    #       'integrated', 'source', 'details'],
    print("Populating Issues Library...")
    response=requests.get((baseUrl+issuesLibraryEndpoint),headers=headers)
    issuesLib_df = pd.DataFrame.from_records(response.json()['result'])
    more = response.json()['more']
    count = 1
    while more == True:
        response=requests.get((baseUrl+issuesLibraryEndpoint+"?page="+str(count)),headers=headers)
        issuesLib_temp = pd.DataFrame.from_records(response.json()['result'])
        issuesLib_df = pd.concat([issuesLib_df,issuesLib_temp])
        more = response.json()['more']
        count=count+1
    
    #get seeds from collection
    #Index(['id', 'type', 'name', 'details', 'claimed', 'seed', 'created_at',
    #       'updated_at', 'last_modified'],
    print("Populating Seeds...")
    seeds_df = util.get_seeds(project_id=projectID,collectionName=collectionName)

    #get entities from collection
    #Index(['id', 'dynamic_id', 'alias_group', 'name', 'type', 'first_seen',
    #       'last_seen', 'collection', 'collection_type', 'collection_naics',
    #       'collection_uuid', 'organization_uuid', 'tags', 'issues',
    #       'exfil_lookup_identifier', 'summary', 'uuid', 'hidden', 'seed',
    #       'aliases', 'updated_at'],
    print("Populating Entities...")
    search_query = "hidden:false"
    entities_df = util.search_data(project_id=projectID,collectionName=collectionName,type="entity",query=search_query)

    print("Populating Inferred CVE Entities...")
    search_query = "hidden:false vuln:cve"
    inferred_cve_df = util.search_data(project_id=projectID,collectionName=collectionName,type="entity",query=search_query)

    #get issues from collection
    #Index(['id', 'uuid', 'dynamic_id', 'name', 'upstream', 'last_seen',
    #       'first_seen', 'entity_uid', 'entity_type', 'entity_name', 'alias_group',
    #        'collection', 'collection_uuid', 'collection_type', 'organization_uuid',
    #       'summary', 'tags', 'collection_naics', 'pretty_name'],
    print("Populating Issues...")
    search_query = "status_new:open"
    issues_df = util.search_data(project_id=projectID,collectionName=collectionName,type="issue",query=search_query)

    count=1
    issuesDetails_df = pd.DataFrame()
    for index,row in issues_df.iterrows():
        print(f"\rPopulating Issue detail... {index}/{len(issues_df)}",end="")
        response=requests.get((baseUrl+"/api/v1/issues/"+str(row['id'])),headers=headers)
        out = response.json()['result']
        del out['details']
        del out['summary']
        del out['identifiers']
        del out['tags']
        mylist = []
        mylist.append(out)
        if count == 1:
            issuesDetails_df = pd.DataFrame.from_records(mylist)
            count=count+1
        else:
            issuesDetails_temp = pd.DataFrame.from_records(mylist)
            issuesDetails_df = pd.concat([issuesDetails_df,issuesDetails_temp])
    #Creating unique list of issues discovered:
    issuesDetails_df = issuesDetails_df.sort_values(by=['severity'], ascending=True)
    unique_issues_list = issuesDetails_df['pretty_name'].unique()
    print("")

    #get tech from collection
    #Index(['id', 'uuid', 'dynamic_id', 'instances', 'version', 'cpe_type', 'cpe',
    #       'collection', 'collection_uuid', 'collection_type', 'update', 'vendor',
    #       'product', 'organization_uuid', 'name', 'updated_at', 'last_seen',
    #       'first_seen', 'unique_instance_count', 'labels'],
    print("Populating Tech...")
    search_query = " "
    tech_df = util.search_data(project_id=projectID,collectionName=collectionName,type="tech",query=search_query)

    #populate summary table
    crit_df = issuesDetails_df.loc[issuesDetails_df['severity'] == 1]
    high_df = issuesDetails_df.loc[issuesDetails_df['severity'] == 2]
    med_df  = issuesDetails_df.loc[issuesDetails_df['severity'] == 3]
    low_df  = issuesDetails_df.loc[issuesDetails_df['severity'] == 4]
    info_df = issuesDetails_df.loc[issuesDetails_df['severity'] == 5]
    util.cell_writeout(cell=document.tables[0].rows[1].cells[1],  text=str(len(seeds_df.index)) )
    util.cell_writeout(cell=document.tables[0].rows[2].cells[1],  text=str(len(entities_df.index)) )
    util.cell_writeout(cell=document.tables[0].rows[3].cells[1],  text=str(len(tech_df.index)) )
    util.cell_writeout(cell=document.tables[0].rows[4].cells[1],  text=str(len(inferred_cve_df.index)) )
    util.cell_writeout(cell=document.tables[0].rows[5].cells[1],  text=str(len(crit_df.index)) )
    util.cell_writeout(cell=document.tables[0].rows[6].cells[1],  text=str(len(high_df.index)) )
    util.cell_writeout(cell=document.tables[0].rows[7].cells[1],  text=str(len(med_df.index )) )
    util.cell_writeout(cell=document.tables[0].rows[8].cells[1],  text=str(len(low_df.index )) )
    util.cell_writeout(cell=document.tables[0].rows[9].cells[1],  text=str(len(info_df.index)) )
    util.cell_writeout(cell=document.tables[0].rows[10].cells[1], text=str(len(issues_df.index)) )
    document.save(docName)

    #Populate seeds table
    count = 1
    for index, row in seeds_df.iterrows():
        document.tables[1].add_row()
        util.cell_writeout(cell=document.tables[1].rows[count].cells[0], text= seeds_df['name'].iloc[(count-1)] )
        util.cell_writeout(cell=document.tables[1].rows[count].cells[1], text= seeds_df['type'].iloc[(count-1)] )
        count = count + 1
    document.save(docName)

    #populate issues table
    count = 1
    for issue in unique_issues_list:
        document.tables[2].add_row()
        severity = to_str(issuesDetails_df.loc[issuesDetails_df['pretty_name'] == issue]['severity'].unique())
        util.cell_writeout(cell=document.tables[2].rows[count].cells[0], text= issue )
        util.cell_writeout(cell=document.tables[2].rows[count].cells[1], text= sev_dict[severity],bold=True)
        _set_cell_background(document.tables[2].rows[count].cells[1], sevcolor_dict[severity])
        document.tables[2].rows[count].cells[1].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

        count2 = 0
        for entity in issuesDetails_df.loc[issuesDetails_df['pretty_name'] == issue]['entity_name']:
            if count2 != 0:
                document.tables[2].rows[count].cells[2].add_paragraph()
            _par_writeout(par=document.tables[2].rows[count].cells[2].paragraphs[count2],text=entity)
            document.tables[2].rows[count].cells[2].paragraphs[count2].alignment = WD_ALIGN_PARAGRAPH.LEFT
            count2 = count2 + 1
        count = count + 1
    document.save(docName)

    #populate issue definitions, remdiations, and recommendations table.
    count = 1
    issue_descption_dic_jp = pd.read_csv("asm_issues_dic_jp.csv",encoding="shift-jis")
    for issue in unique_issues_list:
        for index,issue_def in issuesLib_df.iterrows():
            if issue_def['pretty_name'] == issue:
                document.tables[3].add_row()
                util.cell_writeout(cell=document.tables[3].rows[count].cells[0], text= issue )
                if 'description' in issue_def:
                    description = issue_def['description']
                    font = "Calibri"
                    if issue_descption_dic_jp.loc[issue_descption_dic_jp["pretty_name"]==issue,"description"].empty == False:
                        description = issue_descption_dic_jp.loc[issue_descption_dic_jp["pretty_name"]==issue,"description"].iloc[0]
                        font = "Meiryo UI"
                    util.cell_writeout(cell=document.tables[3].rows[count].cells[1], text= description ,fontname=font)

                if 'remediation' in issue_def:
                    remediation = issue_def['remediation'] 
                    font = "Calibri"
                    if issue_descption_dic_jp.loc[issue_descption_dic_jp["pretty_name"]==issue,"remediation"].empty == False:
                        remediation = issue_descption_dic_jp.loc[issue_descption_dic_jp["pretty_name"]==issue,"remediation"].iloc[0]
                        font = "Meiryo UI"
                    if pd.isna(remediation)==False :
                        util.cell_writeout(cell=document.tables[3].rows[count].cells[2], text= str(remediation) ,fontname=font)

                if 'references' in issue_def:
                    if issue_def['references']:
                        count2 = 2
                        document.tables[3].rows[count].cells[2].add_paragraph()
                        document.tables[3].rows[count].cells[2].paragraphs[1].text = "REFERENCES:"
                        for ref in issue_def['references']:
                            document.tables[3].rows[count].cells[2].add_paragraph()
                            if 'uri' in ref.keys(): # add conditoin 20230914
                                document.tables[3].rows[count].cells[2].paragraphs[count2].text = ref['type'] + ": " + ref['uri']  
                            count2 = count2 + 1 
                count = count + 1
    document.save(docName)

    #populate Tech Table
    if tech_df.empty:
        return document
    tech_df = tech_df.sort_values(by=['name'], ascending=True)
    t = table_num
    count = 1
    for index, row in tech_df.iterrows():
        # 該当entityが0の場合は出力しない
        response=requests.get((baseUrl+entitiesEndPoint+"collection:"+collectionName+" hidden:false last_seen_after:last_refresh cpe:"+row["cpe"]+"?page_size=1000"),headers=headers)
        techEntities_df = pd.DataFrame.from_records(response.json()['result']['hits'])
        if techEntities_df.empty:
            continue

        document.tables[t].add_row()
        util.cell_writeout(cell=document.tables[t].rows[count].cells[0], text= tech_df['name'].iloc[(count-1)] )
        if(isinstance(tech_df['cpe_type'].iloc[(count-1)],str)):
            util.cell_writeout(cell=document.tables[t].rows[count].cells[1], text= tech_df['cpe_type'].iloc[(count-1)])
        util.cell_writeout(cell=document.tables[t].rows[count].cells[2], text= ', '.join(sorted(techEntities_df["name"].tolist()) ))
        document.tables[t].rows[count].cells[2].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.LEFT
        count = count + 1
    document.save(docName)
    print("Report generated: "+docName+"\n")
    return document

# ------------------------------------------------------------
if __name__ == "__main__":
    print("Please run API_ASM2Word.py")




baseUrl = "https://asm-api.advantage.mandiant.com"
projectsEndPoint="/api/v1/projects"
collectionsEndPoint="/api/v1/user_collections/"
entitiesEndPoint ="/api/v1/search/entities/"
entitiydetailEndPoint= "/api/v1/entities/"
issuesEndPoint="/api/v1/search/issues/"
techEndPoint="/api/v1/search/technologies/"
issuesLibraryEndpoint="/api/library/issues"

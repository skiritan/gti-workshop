import pandas as pd
import requests
import json
from docx import Document
import numpy as np

from const_asm_apiendpoint import *
import report_util as util

# ------------------------------------------------------------
def to_str(var):
    return str(list(np.reshape(np.asarray(var), (1, np.size(var)))[0]))[1:-1]

# ------------------------------------------------------------
def create_report(document:Document,table_num:int,projectID:int,collectionName:str)->Document:

    print("# inferred_cve_report")
    docName=("ASM_CustomReport_"+projectID+"-"+collectionName+"_Output.docx")

    # get inferredCVE entities from collection
    # Index(['cve', 'cwe', 'cvss_v2', 'cvss_v3', 'exploits', 'references',
    #        'short_name', 'description', 'cvss_v2_score', 'cvss_v3_score',
    #        'mandiant_intel_details', 'entityname', 'cpe', 'technology'],
    print("Populating InferredCVE Entities...")
    search_query = "hidden:false vuln:cve"
    entities_df = util.search_data(project_id=projectID,collectionName=collectionName,type="entity",query=search_query)

    if len(entities_df) == 0:
        print("\nNo Inferred CVE Entities.")
        return document

    # get inferred_cves from cve_entities 
    # Index(['cve', 'cwe', 'cvss_v2', 'cvss_v3', 'exploits', 'references',
    #    'short_name', 'description', 'cvss_v2_scosre', 'cvss_v3_score',
    #    'mandiant_intel_details', 'entityname', 'cpe', 'vendor', 'version'],
    inferredcve_df = pd.DataFrame()    
    for index,entity in entities_df.iterrows():
        print(f"\rPopulating InferredCVE... {index+1}/{len(entities_df)}, Count:{len(inferredcve_df)}",end="")
        entity = util.get_entity_detail(project_id=projectID,entity_uid=entity["id"])
        entityname = entity["name"]
        for fingerprint in entity["fingerprint"]:
            if "vulns" in fingerprint.keys():
                inferredcve_temp = pd.DataFrame.from_records(fingerprint["vulns"])
                inferredcve_temp["entityname"] = entityname
                inferredcve_temp["cpe"] = fingerprint["cpe"]   
                inferredcve_temp["technology"] = f"{fingerprint['vendor']} {fingerprint['version']}"
                inferredcve_df = pd.concat([inferredcve_df,inferredcve_temp])      
    print("")

    cvss_threshold = 8
    if len (inferredcve_df[inferredcve_df["cvss_v3_score"] > 8] ) < 20:
        print("few inferred cve(cvss>8). change cvss_threshold to 6")
        cvss_threshold = 6
    inferredcve_df = inferredcve_df[inferredcve_df["cvss_v3_score"] > cvss_threshold].sort_values(by="cvss_v3_score", ascending=False)

    # createing InferredCVE report 
    t = table_num  # table_number
    count = 1 # rows_count
    for entityname in inferredcve_df['entityname'].unique():
        df = inferredcve_df[inferredcve_df["entityname"]==entityname]
        document.tables[t].add_row()
        util.cell_writeout (cell=document.tables[t].rows[count].cells[0], text=entityname)
        technologies = to_str(inferredcve_df[inferredcve_df["entityname"]==entityname]['technology'].unique())
        util.cell_writeout (cell=document.tables[t].rows[count].cells[1], text=technologies,bold=True )
        cves=""
        for index, cve in df.iterrows():
            cves = cves + f"{cve['cve']}({cve['cvss_v3_score']}), "
        util.cell_writeout (cell=document.tables[t].rows[count].cells[2], text= cves)
        count = count + 1

    document.save(docName)
    print("Report generated: "+docName+"\n")
    return document

# ------------------------------------------------------------
if __name__ == "__main__":
    print("Please run API_ASM2Word.py")



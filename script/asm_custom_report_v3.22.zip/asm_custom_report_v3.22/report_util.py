
from const_asm_apiendpoint import *
import pandas as pd
import os
import requests
from docx.table import _Cell
from docx.shared import Pt
from docx.oxml.ns import qn

# ------------------------------------------------------------
# get seed information.
def get_seeds(project_id:int,collectionName:str) -> pd.DataFrame:
    accessKey = os.getenv('ASM_ACCESS_KEY')
    accessSecret = os.getenv('ASM_ACCESS_SECRET')
    _headers = {"INTRIGUE_ACCESS_KEY":accessKey, "INTRIGUE_SECRET_KEY":accessSecret,'PROJECT_ID':str(project_id)}

    # get collectionUUID from collectionName
    response=requests.get((baseUrl+collectionsEndPoint),headers=_headers)
    collections_df = pd.DataFrame.from_records(response.json()['result'])
    collectionUUID = collections_df.loc[collections_df['name']==collectionName,'uuid'].iloc[0]

    print("Populating Seeds...")
    response=requests.get((baseUrl+collectionsEndPoint+collectionUUID+"/user_entities"),headers=_headers)
    seeds_df = pd.DataFrame.from_records(response.json()['result'])
    if seeds_df.empty:
        print("[Alert] no seed found")
    return seeds_df


# ------------------------------------------------------------
# search entity/issue/tech data with query string.
def search_data(project_id:int,collectionName:str,type:str, query:str) -> pd.DataFrame:
    page_size = 1000

    accessKey = os.getenv('ASM_ACCESS_KEY')
    accessSecret = os.getenv('ASM_ACCESS_SECRET')
    _headers = {"INTRIGUE_ACCESS_KEY":accessKey, "INTRIGUE_SECRET_KEY":accessSecret,'PROJECT_ID':str(project_id)}

    api_endpoint ={
        "entity" : entitiesEndPoint,
        "issue" : issuesEndPoint,
        "tech" : techEndPoint,
    }
    search_query = "collection:" + collectionName + " " + query + "?page_size=" + str(page_size)

    print(f"Searching {type} data...",end="")
    response=requests.get((baseUrl+api_endpoint[type] +search_query),headers=_headers)
    if response.status_code != 200:
        print(response)
        return False # TASK: raise exception.
 
    total_pages = response.json()['result']['total_pages']
    data_df = pd.DataFrame.from_records(response.json()['result']['hits'])

    page = 1
    if total_pages > 1:
        while total_pages > page:
            print(f"\rSearching {type} data... {page}/{total_pages}, Count:{len(data_df)} ",end="")
            response=requests.get((baseUrl+api_endpoint[type]+ search_query+"&page="+str(page)), headers=_headers)
            data_temp = pd.DataFrame.from_records(response.json()['result']['hits'])
            data_df = pd.concat([data_df,data_temp])
            page=page+1

    print(f"\rSearching {type} data... {page}/{total_pages}, Count:{len(data_df)}")
    data_df = data_df.reset_index(drop=True)
    if len(data_df) ==10000:
        print("[Alert] data count: 10000 ")
    return data_df


# ------------------------------------------------------------
# get entities details 
# dict_keys(['uuid', 'dynamic_id', 'collection_name', 'alias_group', 'aliases', 
# 'allow_list', 'ancestors', 'category', 'collection_naics', 'confidence', 'deleted', 
# 'deny_list', 'details', 'details_file', 'description', 'first_seen', 'hidden', 
# 'last_seen', 'name', 'scoped', 'scoped_reason', 'seed', 'source', 'status', 
# 'task_results', 'type', 'uid', 'created_at', 'updated_at', 'collection_id', 
# 'elasticsearch_mappings_hash', 'collection', 'collection_uuid', 'organization_uuid', 
# 'collection_type', 'fingerprint', 'summary', 'tags'])
def get_entity_detail(project_id:int,entity_uid:str) -> dict :
    accessKey = os.getenv('ASM_ACCESS_KEY')
    accessSecret = os.getenv('ASM_ACCESS_SECRET')
    _headers = {"INTRIGUE_ACCESS_KEY":accessKey, "INTRIGUE_SECRET_KEY":accessSecret,'PROJECT_ID':str(project_id)}

    response = requests.get(baseUrl+entitiydetailEndPoint+entity_uid,headers=_headers)
    #TASK: Error Handleing
    return response.json()['result']

# ------------------------------------------------------------
# write out text to docx celss with font/style
# ------------------------------------------------------------
def cell_writeout(cell:_Cell,text:str,fontname:str="Calibri",fontsize:int=10,bold=False):
    cell.text = text
    cell.paragraphs[0].runs[0].font.name = fontname
    cell.paragraphs[0].runs[0].font.size = Pt(fontsize)

    if fontname != "Calibri":
        cell.paragraphs[0].runs[0]._element.rPr.rFonts.set(qn('w:eastAsia'), fontname)
    if bold:
        cell.paragraphs[0].runs[0].font.bold = 1
    return 

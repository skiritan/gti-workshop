import pandas as pd
import requests
import json
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
import numpy as np

from publicsuffix2 import fetch, get_sld, get_tld
from const_asm_apiendpoint import *
import report_util as util

# ------------------------------------------------------------
def to_str(var):
    return str(list(np.reshape(np.asarray(var), (1, np.size(var)))[0]))[1:-1]

# ------------------------------------------------------------
def create_report(document:Document,table_num:int,projectID:int,collectionName:str)->Document:

    print("# domain_report")
    docName=("ASM_CustomReport_"+projectID+"-"+collectionName+"_Output.docx")

    # get seeds from collection
    # Columns:Index(['id', 'type', 'name', 'details', 'claimed', 'seed', 'created_at',
    #        'updated_at', 'last_modified'],
    print("Populating Seeds...")
    seeds_df = util.get_seeds(project_id=projectID,collectionName=collectionName)

    # get DNSRecord entities from collection 
    # Index(['cve', 'cwe', 'cvss_v2', 'cvss_v3', 'exploits', 'references',
    #        'short_name', 'description', 'cvss_v2_score', 'cvss_v3_score',
    #        'mandiant_intel_details', 'entityname', 'cpe', 'technology'],
    #       dtype='object')
    print("Populating DNSRecord Entities...")    
    search_query = "hidden:false type:DnsRecord"
    entities_dnsrecord_df = util.search_data(project_id=projectID,collectionName=collectionName,type="entity",query=search_query)

    if entities_dnsrecord_df.empty:
        print("No DNSRecord Entities.")
        return document

    seed_domains = seeds_df[seeds_df["type"]=="Domain"]["name"].to_list()
    found_domains = []
    subdomains = {}
    for seed in subdomains:
        subdomains[seed]=[]

    for index,entity in entities_dnsrecord_df.iterrows():
        print(f"\rAnalyzing DNSRecord Entities ... {index+1}/{len(entities_dnsrecord_df)} - {entity['name']}",end="")
        # get org-domain name (ex:asm.advantage.mandiant.co.jp)
        tld_domain = get_tld(entity["name"])  # co.jp
        org_domain = ".".join( entity["name"].split(".")[(-1)*(tld_domain.count(".")+2):])  # mandiant.co.jp
        sub_domain = entity["name"].replace(org_domain,"")[:-1]  # asm.advantage

        if org_domain in subdomains.keys():
            subdomains[org_domain].append(sub_domain)
        else:
            # get ancestors from entity detail.
            detail = util.get_entity_detail(project_id=property,entity_uid=entity["id"])
            found_domains.append({"domainname":org_domain,"ancestors":detail["ancestors"][0]["name"]})
            subdomains[org_domain]=[]
            subdomains[org_domain].append(entity["name"].replace(org_domain,"")[:-1])

    print("")

    # createing Subdomain report 
    count = 1
    t = table_num  # table_number
    for seed,subdomains in sorted(subdomains.items()):
        discovered_type = "Seed" if seed in seed_domains else "-"

        document.tables[t].add_row()
        util.cell_writeout (cell=document.tables[t].rows[count].cells[0], text=seed)
        util.cell_writeout (cell=document.tables[t].rows[count].cells[1], text=discovered_type)
        document.tables[t].rows[count].cells[1].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        util.cell_writeout (cell=document.tables[t].rows[count].cells[2], text= str(', '.join(sorted(subdomains))))

        count = count + 1
    document.save(docName)
    print("Report generated: "+docName+"\n")
    return document

# ------------------------------------------------------------
if __name__ == "__main__":
    print("Please run API_ASM2Word.py")

